create view avg_zp as
  select
    avg(`geek1211`.`shtat`.`zp`) AS `СРЕД ЗП`,
    `geek1211`.`depart`.`name`   AS `департамент`
  from (`geek1211`.`shtat`
    left join `geek1211`.`depart` on ((`geek1211`.`shtat`.`otdel` = `geek1211`.`depart`.`dep_id`)))
  group by `geek1211`.`shtat`.`otdel`;

