create function findEmp(emp varchar(45))
  returns text
  RETURN (SELECT * FROM `shtat` WHERE  `name` = emp);

